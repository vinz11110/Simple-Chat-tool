package at.ac.hcw.simplechattool.ServerCode;

public class ListHandler {
}
