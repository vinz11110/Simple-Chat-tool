package at.ac.hcw.simplechattool;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(ChatApp.class, args);
    }
}
